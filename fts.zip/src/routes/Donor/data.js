export const columns = ["Sl No", "Edit", "Name", "Type", "Spouse/Contact", "Mobile", "Email", "Receipt"];
export const table = [
    ["1", "", "Nagesh K. S", "Individual", "","9845428143","ksnageshblr@gmail.com","Button"],
    ["2", "", "Anita Todi", "Individual", "Shri Shiv kumar Todi","9448372955","steelcompostion@rediffmail.com","Button"],
    ["3", "", "M/s Gajraj Jewellers (OPC) Pvt. Ltd.", "Private", "Mr. Vijay","9845741235","dinesh_printers@hotmail.com",""],
    ["4", "", "	M/s P. C. Associates", "Private", "Gajendra Kumar Agarwal","	9343762500","",""]
];
export const options = { filterType: 'dropdown' };
const corr_preffer = [
    {
      value: 'Registered',
      label: 'Registered',
    },
    {
      value: 'Branch Office',
      label: 'Branch Office',
    },
    {
      value: 'Digital',
      label: 'Digital',
    },
  ];