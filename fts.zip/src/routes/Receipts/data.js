
export const columns = ["SlNo", "Receipt No", "Name", "Date", "Exemption Type", "Amount", "View", "Edit"];
export const data = [
    ["224", "4747", "Shiv kumar Todi", "05-02-2021", "80G", "2000","", ""],
			["223", "4746", "Kanta Devi Banka", "05-02-2021", "80G", "2000","", ""],
			["222", "4745", "Nagesh K. S", "05-02-2021", "Non 80G", "1000","", ""],
			["221", "4744", "Vijay Kumar Banka", "05-02-2021", "80G", "22000","", ""]
];
export const options = { filterType: 'dropdown' };